#!/usr/bin/env bash

## Launch Top bar
echo "---" | tee -a /tmp/polybar1.log
polybar Top 2>&1 | tee -a /tmp/polybar1.log & disown

echo "Top Bar launched..."

# Launch Bottom bar
echo "---" | tee -a /tmp/polybar1.log
polybar Bottom 2>&1 | tee -a /tmp/polybar1.log & disown

echo "Bottom Bar launched..."
